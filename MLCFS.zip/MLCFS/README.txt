Run MLCFS.py to execute MLCFS

Input: 
	data_train: Training data
	alpha: significance level
	L: #labels
	k1,k2: parameters 
	datatype: C or D
	
Output:
	selected features