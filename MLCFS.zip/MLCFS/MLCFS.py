import numpy as np
import warnings
import pandas as pd
from  MLCFSD import MLCFSD
from MLCFSC import MLCFSC
import matlab.engine
import matlab
import scipy.io as sio
eng = matlab.engine.start_matlab()



def MLCFS(data, alpha, L,k1,k2,datatype):
    if datatype == 'D':
        resultM = MLCFSD(data,alpha,L,k1,k2)
    else:
        resultM = MLCFSC(data,alpha,L,k1,k2)

    return resultM
if __name__ == "__main__":
    """An example of MLCFS"""

    dataset = sio.loadmat("xxx.mat")
    data = dataset["train"]
    alpha = 0.05 # Significance
    L = 6 # labels
    k1 = 0.3;k2 = 0.5
    datatype = "C" # C or D
    resultM = MLCFS(data,alpha,L,k1,k2,datatype)